create definer = root@localhost trigger updateStock
    before insert
    on invoice_item
    for each row
BEGIN
	UPDATE item_stock SET item_stock.item_stock_qty = item_stock.item_stock_qty - NEW.invoice_item_qty WHERE NEW.invoice_item_id = item_stock.item_id;
END;

